insert into t_chapter (name,stage_id) values ('程序员的基本素养和职业规划', 1);
insert into t_chapter (name,stage_id) values ('JAVA 技术体系介绍和学习方法', 1);
insert into t_chapter (name,stage_id) values ('就业和找工作需要注意事项', 1);

insert into t_chapter (name,stage_id) values ('JAVA入门和背景知识', 2);
insert into t_chapter (name,stage_id) values ('变量、数据类型、运算符', 2);
insert into t_chapter (name,stage_id) values ('IDEA的使用和第一个java项目', 2);
insert into t_chapter (name,stage_id) values ('控制语句、方法、递归算法', 2);
insert into t_chapter (name,stage_id) values ('面向对象详解和JVM底层内存分析', 2);
insert into t_chapter (name,stage_id) values ('数组和数据存储', 2);
insert into t_chapter (name,stage_id) values ('飞机大战小项目训练', 2);

insert into t_chapter (name,stage_id) values ('Python入门(动画版)', 27);
insert into t_chapter (name,stage_id) values ('编程基本概念', 27);
insert into t_chapter (name,stage_id) values ('序列', 27);
insert into t_chapter (name,stage_id) values ('控制语句', 27);
insert into t_chapter (name,stage_id) values ('函数和内存分析', 27);
insert into t_chapter (name,stage_id) values ('面向对象', 27);
insert into t_chapter (name,stage_id) values ('Python开发环境搭建', 27);

insert into t_chapter (name,stage_id) values ('异常机制', 28);
insert into t_chapter (name,stage_id) values ('文件处理', 28);
insert into t_chapter (name,stage_id) values ('模块', 28);
insert into t_chapter (name,stage_id) values ('坦克大战', 28);

insert INTO t_chapter (name,stage_id) VALUES ('程序员的职业规划', 43);
insert INTO t_chapter (name,stage_id) VALUES ('前端技术体系', 43);
insert INTO t_chapter (name,stage_id) VALUES ('学习方法', 43);

insert INTO t_chapter (name,stage_id) VALUES ('前端入门与基础知识', 44);
insert INTO t_chapter (name,stage_id) VALUES ('HTML5基础元素', 44);
insert INTO t_chapter (name,stage_id) VALUES ('表单', 44);
insert INTO t_chapter (name,stage_id) VALUES ('实体字符与元素分类', 44);
insert INTO t_chapter (name,stage_id) VALUES ('HTML5新增元素', 44);
insert INTO t_chapter (name,stage_id) VALUES ('初识CSS', 44);
insert INTO t_chapter (name,stage_id) VALUES ('CSS常用属性', 44);
insert INTO t_chapter (name,stage_id) VALUES ('CSS选择器', 44);
insert INTO t_chapter (name,stage_id) VALUES ('CSS盒子模型', 44);
insert INTO t_chapter (name,stage_id) VALUES ('浮动与定位', 44);
insert INTO t_chapter (name,stage_id) VALUES ('CSS3新特性', 44);
insert INTO t_chapter (name,stage_id) VALUES ('CSS应用技巧', 44);
insert INTO t_chapter (name,stage_id) VALUES ('商城官网项目', 44);
insert INTO t_chapter (name,stage_id) VALUES ('响应式项目', 44);

