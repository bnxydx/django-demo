from django.apps import AppConfig


class DwrgConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "dwrg"
